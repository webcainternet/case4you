<?php 
ini_set( 'error_log','/tmp/php-debug.log' );
phpinfo();
?>
